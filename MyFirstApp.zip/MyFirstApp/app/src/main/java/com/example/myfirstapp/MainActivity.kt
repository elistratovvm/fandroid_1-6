package com.example.myfirstapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var textView: TextView
    private lateinit var textEditView: TextView
    private lateinit var editText: EditText
    private lateinit var buttonEditText: Button
    lateinit var myObserver: MyObserver

    override fun onSaveInstanceState(outState: Bundle?) {

        super.onSaveInstanceState(outState)
        outState?.run {
            putString("KEY", textView.text.toString())
        }

    }

    public override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textView = findViewById(R.id.textView)

        myObserver = MyObserver()
        lifecycle.addObserver(myObserver)

        textEditView = findViewById(R.id.textEditView)
        buttonEditText = findViewById(R.id.buttonEditText)
        editText = findViewById(R.id.editText)

        buttonEditText.setOnClickListener {
            textEditView.text = editText.text
        }
    }

    override fun onStart() {
        super.onStart()
        toastMeState("ON_START")
    }

    override fun onResume() {
        super.onResume()
        toastMeState("ON_RESUME")
    }

    override fun onPostResume() {
        super.onPostResume()
        toastMeState("onPostResume")
    }

    override fun onPause() {
        super.onPause()
        toastMeState("ON_PAUSE")
    }

    override fun onStop() {
        super.onStop()
        toastMeState("ON_STOP")
    }

    override fun onRestart() {
        super.onRestart()
        toastMeState("onRestart")
    }

    override fun onDestroy() {
        super.onDestroy()
        toastMeState("ON_DESTROY")
    }

    fun toastMe(view: View) {
            // Выводим toast
        Toast.makeText(this, "Hello Toast!", Toast.LENGTH_SHORT).show()
    }

    private fun toastMeState(message: String) {
        // Выводим toast с текущим состоянием activity
        Toast.makeText(this, "${lifecycle.currentState}, $message", Toast.LENGTH_LONG).show()
    }

    fun randomMe(view: View) {
            // Создаем intent для запуска secondActivity
        val randomIntent = Intent(this, SecondActivity::class.java)
            // Получаем текстовое значение поля textView из activity
        val countString = textView.text.toString()
            // Конвертируем в int
        val count = Integer.parseInt(countString)
            // Добавлем count к дополнениям?(extra) для randomIntent
        randomIntent.putExtra(SecondActivity.TOTAL_COUNT, count)
            // Запускаем secondActivity
        startActivity(randomIntent)
    }

    fun countMe (view: View) {
            // Получаем текстовое значение поля textView из activity
        val countString = textView.text.toString()
            // Конвертируем в int и прибавляем 1
        var count: Int = Integer.parseInt(countString)
        count++
            // Кладем новое значение в textView
        textView.text = count.toString()
    }
}